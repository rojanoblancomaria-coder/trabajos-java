/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Empleado {
    String Nombre;
    int Documento;
    String Cargo;
    String Area;
    Double Salario;
    String Fecha;
    
public Empleado(){
} 

    public Empleado(String Nombre, int Documento, String Cargo, String Area, double Salario, String Fecha) {
        this.Nombre = Nombre;
        this.Documento = Documento;
        this.Cargo = Cargo;
        this.Area = Area;
        this.Salario = Salario;
        this.Fecha=Fecha;
    }
public String getNombre(){
    return Nombre;
}
 
public void setNombre(String Nombre){
    this.Nombre=Nombre;
}
public int getDocumento(){
    return Documento;
}
public void setDocumento(int Documento){
    this.Documento=Documento;
}
public String getCargo(){
    return Cargo;
}
public void setCargo (String cargo){
    this.Cargo=Cargo;
}
public String getArea(){
   return Area;
}
public void setArea(String Area){
    this.Area=Area;
}
public Double getSalario(){
    return Salario;
}
public void setSalario( Double Salario){
    this.Salario=Salario;
}
public String getFecha(){
    return Fecha;
}
public void setFecha(String Fecha){
    this.Fecha=Fecha;
}

}
