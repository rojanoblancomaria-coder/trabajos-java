/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package menu;

import javax.swing.JOptionPane;
import java.util.Scanner;
       
public class Menu {

   
    public static void main(String[] args) {
     Scanner teclado = new Scanner(System.in);
     String aparecerM;
     int menu;
     double descuento = 0, total =0, adicion = 0;
     Comidas op=new Comidas();
     
        System.out.println("Desea el menu? (Ingrese si o no)");
        aparecerM = teclado.next();
        
        switch(aparecerM){
            case"SI": case"Si": case"si":
                System.out.println("          Menu             Precio            Adicion         Descuento");
                System.out.println("");
                System.out.println("1)    Bandeja Paisa         25.000       Chicharron/chorizo      10%");
                System.out.println("2)    Mondongo              20.000       Ensalada/patacon        15%");
                System.out.println("3)    Sancocho              25.000       Ensalada/arroz          10%");
                System.out.println("4)    Menu del dia          20.000       NA                      NA   ");
                
                System.out.println("que desea ordenar?   ");
                
                
                menu = teclado.nextInt();
                switch(menu){
                    case 1:
                        op.paisa(total, descuento, adicion);
                        break;
                        
                     case 2:
                        op.Mondongo(total, descuento, adicion);
                        break;
                    
                    case 3:
                        op.Sancocho(total, descuento, adicion);
                        break;
                        
                    case 4:
                       int menu_del_dia=   20000;
                       
                        System.out.println("menu del dia");
                        System.out.println(" menu del dia " + menu_del_dia);
                        break;
                        
                }
                
                
                
                
                
                
        } 
    }
    
}
