/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package menu;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class Comidas {
    Scanner teclado = new Scanner(System.in);
    
    public double paisa(double total, double descuento,double adicion){
        System.out.println("Desea la adicion ( 1 para si/ 2 para no");
        adicion = teclado.nextInt();
        
        if(adicion == 1){
            total= 25000;
            adicion= 25000;
            total= total + adicion;
            descuento = total - adicion;
            System.out.println("Bandeja paisa");
            System.out.println("descuento + descuento");
            System.out.println("adicion + adicion");
            System.out.println("total + total");
            return total;
        }
        
        
         else{
            total= 25000;
            descuento=total*0.10;
            System.out.println("bandeja paisa");
            System.out.println("descuento + descuento");
            System.out.println("adicion + adicion");
            System.out.println("total + total");
            return total;
            
             }
     }    
    
    public double Mondongo(double total, double descuento,double adicion){
        System.out.println("Desea la adicion ( 1 para si/ 2 para no");
        adicion = teclado.nextInt();
        
        if(adicion == 1){
            total= 20000;
            adicion= 20000;
            total= total + adicion;
            descuento = total - adicion;
            System.out.println("mondongo");
            System.out.println("descuento" + descuento);
            System.out.println("adicion" + adicion);
            System.out.println("total" + total);
            return total;
        }
        
        else{
            total= 20000;
            descuento=total*0.15;
            System.out.println("mondongo");
            System.out.println("descuento" + descuento);
            System.out.println("adicion" + adicion);
            System.out.println("total" + total);
            return total;
            
             }
    }
    
    
    public double Sancocho(double total, double descuento,double adicion){
        System.out.println("Desea la adicion ( 1 para si/ 2 para no");
        adicion = teclado.nextInt();
         
        
         if(adicion == 1){
            total= 25000;
            adicion= 25000;
            total= total + adicion;
            descuento = total - adicion;
            System.out.println("Sancocho");
            System.out.println("descuento" + descuento);
            System.out.println("adicion" + adicion);
            System.out.println("total" + total);
            return total;
        }
        
        else{
            total= 25000;
            descuento=total*0.10;
            System.out.println("Sancocho");
            System.out.println("descuento" + descuento);
            System.out.println("adicion" + adicion);
            System.out.println("total" + total);
            return total;
            
             }
    }
    
   
    
    
    
}