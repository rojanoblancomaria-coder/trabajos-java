/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
    
public class principal {
    
    public static void main (String[] args) {
        
       cafetera miCafetera = new cafetera ("oster", "negra");
       
       miCafetera.prepararCafe();
        
    }
}
