/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class cafetera {
    
    String marca;
    String color;
    
    public cafetera(String marca, String color) {
        this.marca = marca;
        this.color = color;
        
    }
    
    
    public void prepararCafe() {
        
        System.out.println("1. calentando agua a 90 grados");
        System.out.println("2. filtrando el agua a travez del cafe molido");
        System.out.println("3. su cafe esta listo");
    }
    
}
