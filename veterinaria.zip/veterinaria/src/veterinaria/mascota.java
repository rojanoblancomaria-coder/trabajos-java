/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veterinaria;

/**
 *
 * @author user
 */
public class mascota {
    private  String nombre;
    private  String especie;
    private  int edad;
             
    public void setnombre( String nombre){
      
      this.nombre= nombre;
      
  }           
    public String getnombre(){
    
    return nombre;
  
  }
    
  
    public void setespecie( String nombre){
      
      this.especie= especie;
      
  }           
    public String getespecie(){
    
    return especie;
  
  }
   
 
    
  public void setedad( int edad){
      
      this.edad= edad;
      
  }           
    public int getedad(){
    
    return edad;
  
  }  
    
    
    
}

