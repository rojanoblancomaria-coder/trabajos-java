/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package veterinaria;

/**
 *
 * @author user
 */
public class tipo_de_mascota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mascota mascota1 = new mascota();
        
        
        mascota1.setnombre("firulais");
        
        mascota1.setespecie("perro");
        
        mascota1.setedad(5);
        
        System.out.println("datos iniciales" );
        System.out.println("nombre:  " + mascota1.getnombre());
        System.out.println("especie:  " + mascota1.getespecie());
        System.out.println("edad:  " + mascota1.getedad());
        
        
        
        
        mascota1.setedad(8);
        
        System.out.println("datos actualizados" );
        System.out.println("nombre:  " + mascota1.getnombre());
        System.out.println("especie:  " + mascota1.getespecie());
        System.out.println("edad:  " + mascota1.getedad());
    }
    
}
